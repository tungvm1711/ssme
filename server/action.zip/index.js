const watsonApiKey = require('./watson-nlu.json').apikey;
const NaturalLanguageUnderstandingV1 = require('ibm-watson/natural-language-understanding/v1.js');
const naturalLanguageUnderstanding = new NaturalLanguageUnderstandingV1({
  version: '2018-11-16',
  iam_apikey: 'Z6iZ-ClMf8aHpjVxDOif52_AyYyqWv0PlYhhbiNHbOih',
  url: 'https://gateway-lon.watsonplatform.net/natural-language-understanding/api',
})

function main(params) {
  const parameters = {
    url: params.url,
    features: {
      entities: {
        emotion: true,
        limit: 8,
      },
    },
  }

  return new Promise((resolve, reject) => {
    naturalLanguageUnderstanding.analyze(parameters, (err, response) => {
      if (err) {
        reject({
          status: 500,
          body: err,
        })
      } else {
        resolve({
          status: 200,
          body: response,
        })
      }
    })
  })
}
